import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import { Place, PlaceStatus, Coordinates } from '../types';
import { MapPin, CheckCircle2, CircleDashed } from 'lucide-react';
import ReactDOMServer from 'react-dom/server';

// Fix for default Leaflet marker icons in React
// We are using custom DivIcons instead, so this is less critical, but good practice.

interface WorldMapProps {
  places: Place[];
  selectedPlaceId: string | null;
  onMapClick: (coords: Coordinates) => void;
  onPlaceSelect: (id: string) => void;
}

// Component to handle map events
const MapEvents: React.FC<{ onClick: (coords: Coordinates) => void }> = ({ onClick }) => {
  useMapEvents({
    click(e) {
      onClick({ lat: e.latlng.lat, lng: e.latlng.lng });
    },
  });
  return null;
};

// Component to fly to selected place
const MapFlyTo: React.FC<{ coords: Coordinates | null }> = ({ coords }) => {
  const map = useMap();
  useEffect(() => {
    if (coords) {
      map.flyTo([coords.lat, coords.lng], 10, {
        duration: 1.5
      });
    }
  }, [coords, map]);
  return null;
};

const WorldMap: React.FC<WorldMapProps> = ({ places, selectedPlaceId, onMapClick, onPlaceSelect }) => {
  const selectedPlace = places.find(p => p.id === selectedPlaceId);

  const createCustomIcon = (status: PlaceStatus, isSelected: boolean) => {
    const colorClass = status === PlaceStatus.VISITED ? 'text-emerald-600' : 'text-rose-500';
    const bgClass = isSelected ? 'bg-white scale-125 shadow-xl' : 'bg-white/90 shadow-md';
    const IconComponent = status === PlaceStatus.VISITED ? CheckCircle2 : MapPin;

    const iconHtml = ReactDOMServer.renderToString(
      <div className={`p-2 rounded-full border-2 border-white transition-transform ${colorClass} ${bgClass}`}>
        <IconComponent size={24} fill={status === PlaceStatus.VISITED ? "currentColor" : "none"} strokeWidth={2.5} />
      </div>
    );

    return L.divIcon({
      html: iconHtml,
      className: 'bg-transparent', // Remove default leaflet square
      iconSize: [40, 40],
      iconAnchor: [20, 40], // Bottom point of the pin
      popupAnchor: [0, -40],
    });
  };

  return (
    <div className="h-full w-full z-0 relative">
      <MapContainer
        center={[20, 0]}
        zoom={2}
        scrollWheelZoom={true}
        style={{ height: '100%', width: '100%' }}
        className="outline-none"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
        />
        
        <MapEvents onClick={onMapClick} />
        <MapFlyTo coords={selectedPlace ? { lat: selectedPlace.lat, lng: selectedPlace.lng } : null} />

        {places.map((place) => (
          <Marker
            key={place.id}
            position={[place.lat, place.lng]}
            icon={createCustomIcon(place.status, place.id === selectedPlaceId)}
            eventHandlers={{
              click: () => onPlaceSelect(place.id),
            }}
          >
            <Popup className="font-sans">
              <div className="text-center">
                <h3 className="font-bold text-lg text-slate-800">{place.name}</h3>
                <p className="text-xs uppercase tracking-wider font-semibold text-slate-500 mb-2">
                  {place.status === PlaceStatus.VISITED ? 'Visited' : 'Bucket List'}
                </p>
                {place.notes && <p className="text-sm text-slate-600 italic">"{place.notes}"</p>}
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
};

export default WorldMap;
