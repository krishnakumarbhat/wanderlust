import { GoogleGenAI, Type } from "@google/genai";
import { Place, PlaceStatus } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const getTravelRecommendations = async (visitedPlaces: Place[]): Promise<any[]> => {
  if (!apiKey) {
    console.warn("Gemini API Key is missing");
    return [];
  }

  const visitedNames = visitedPlaces
    .filter(p => p.status === PlaceStatus.VISITED)
    .map(p => p.name)
    .join(", ");

  const prompt = `
    I have visited the following places: ${visitedNames}.
    Based on my travel history (or general popular travel destinations if the history is empty),
    suggest 3 unique and interesting places I should add to my bucket list.
    Provide the name, a short 1-sentence description, and the latitude/longitude coordinates for each.
    Ensure coordinates are accurate.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              description: { type: Type.STRING },
              lat: { type: Type.NUMBER },
              lng: { type: Type.NUMBER },
            },
            required: ["name", "description", "lat", "lng"],
          },
        },
      },
    });

    const text = response.text;
    if (!text) return [];
    return JSON.parse(text);
  } catch (error) {
    console.error("Error getting recommendations:", error);
    return [];
  }
};

export const getPlaceInfo = async (placeName: string): Promise<string> => {
  if (!apiKey) return "API Key missing.";

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Write a very brief (2 sentences max) interesting fact or travel tip about ${placeName}.`,
    });
    return response.text || "No info available.";
  } catch (error) {
    console.error("Error fetching place info", error);
    return "Could not fetch info.";
  }
};
